package com.example.liquidhometv;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.KeyEvent;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.ImageView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private TextView clock, date;
    private LinearLayout appStrip;
    private boolean showingAll = true;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512 | 4096);
        FrameLayout root = new FrameLayout(this);
        root.addView(new AnimatedSea(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(42), dp(28), dp(42), dp(28));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, -1);
        root.addView(page, pp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.TOP);
        top.setOrientation(LinearLayout.HORIZONTAL);
        page.addView(top, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout timeBox = new LinearLayout(this);
        timeBox.setOrientation(LinearLayout.VERTICAL);
        top.addView(timeBox, new LinearLayout.LayoutParams(0, -2, 1f));
        date = new TextView(this); date.setTextColor(Color.rgb(255,218,112)); date.setTextSize(20); date.setTypeface(null, 1);
        timeBox.addView(date);
        clock = new TextView(this); clock.setTextColor(Color.WHITE); clock.setTextSize(72); clock.setTypeface(null, 1); clock.setShadowLayer(14,0,5,0x885C72FF);
        timeBox.addView(clock);

        LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.RIGHT|Gravity.TOP);
        top.addView(actions, new LinearLayout.LayoutParams(-2, -2));
        TextView settings = pill("⚙  Ajustes");
        TextView apps = pill("▦  Aplicaciones");
        actions.addView(settings); actions.addView(space(12)); actions.addView(apps);
        settings.setOnClickListener(v -> { try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); } catch(Exception ignored){} });
        apps.setOnClickListener(v -> { showingAll = !showingAll; populateApps(); });

        TextView hint = new TextView(this); hint.setText("TUS APLICACIONES"); hint.setTextColor(0xCCFFFFFF); hint.setTextSize(13); hint.setLetterSpacing(.16f); hint.setPadding(2,0,0,12);
        page.addView(hint, new LinearLayout.LayoutParams(-1,-2));
        HorizontalScrollView scroller = new HorizontalScrollView(this); scroller.setHorizontalScrollBarEnabled(false); scroller.setClipToPadding(false);
        page.addView(scroller, new LinearLayout.LayoutParams(-1, dp(142)));
        appStrip = new LinearLayout(this); appStrip.setOrientation(LinearLayout.HORIZONTAL); appStrip.setGravity(Gravity.CENTER_VERTICAL);
        scroller.addView(appStrip, new HorizontalScrollView.LayoutParams(-2,-1));
        populateApps();
        setContentView(root);
        updateTime();
        handler.postDelayed(new Runnable(){ public void run(){ updateTime(); handler.postDelayed(this,1000); }},1000);
    }

    private void updateTime(){
        Date now = new Date();
        clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
        String d = new SimpleDateFormat("EEEE, d 'de' MMMM", new Locale("es","ES")).format(now);
        if(d.length()>0) d = d.substring(0,1).toUpperCase(new Locale("es","ES"))+d.substring(1);
        date.setText(d);
    }

    private void populateApps(){
        if(appStrip==null)return;
        appStrip.removeAllViews();
        PackageManager pm=getPackageManager();
        Intent query=new Intent(Intent.ACTION_MAIN,null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> items=pm.queryIntentActivities(query,0);
        Collections.sort(items, new Comparator<android.content.pm.ResolveInfo>() { public int compare(android.content.pm.ResolveInfo a, android.content.pm.ResolveInfo b){ return String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))); }});
        for(android.content.pm.ResolveInfo ri:items){
            String pkg=ri.activityInfo.packageName;
            if(pkg.equals(getPackageName())) continue;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setPadding(dp(10),dp(8),dp(10),dp(6));
            GradientDrawable bg=new GradientDrawable(); bg.setColor(0xDDE8E9FF); bg.setCornerRadius(dp(20)); bg.setStroke(dp(1),0x77FFFFFF); card.setBackground(bg); card.setFocusable(true); card.setFocusableInTouchMode(true);
            ImageView icon=new ImageView(this); try{ icon.setImageDrawable(ri.loadIcon(pm)); }catch(Exception ignored){}; card.addView(icon,new LinearLayout.LayoutParams(dp(54),dp(54)));
            TextView label=new TextView(this); label.setText(ri.loadLabel(pm)); label.setTextColor(0xFF17152D); label.setTextSize(12); label.setMaxLines(1); label.setGravity(Gravity.CENTER); label.setPadding(0,dp(5),0,0); card.addView(label,new LinearLayout.LayoutParams(dp(102),-2));
            card.setOnClickListener(v->{ Intent launch=pm.getLaunchIntentForPackage(pkg); if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch);} });
            card.setOnFocusChangeListener((v,focused)->{ v.animate().scaleX(focused?1.09f:1f).scaleY(focused?1.09f:1f).setDuration(140).start(); v.setElevation(focused?dp(16):dp(2)); });
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(124),dp(126)); lp.setMargins(0,0,dp(14),0); appStrip.addView(card,lp);
        }
        if(appStrip.getChildCount()>0) appStrip.getChildAt(0).requestFocus();
    }

    private TextView pill(String s){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(16); t.setGravity(Gravity.CENTER); t.setPadding(dp(20),dp(12),dp(20),dp(12)); GradientDrawable d=new GradientDrawable(); d.setColor(0x553C3B9B); d.setCornerRadius(dp(32)); d.setStroke(dp(1),0x66FFFFFF); t.setBackground(d); t.setFocusable(true); t.setClickable(true); t.setElevation(dp(4)); return t; }
    private View space(int w){ View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),1)); return v; }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}

    @Override protected void onDestroy(){super.onDestroy();handler.removeCallbacksAndMessages(null);}

    private static class AnimatedSea extends View {
        Paint p=new Paint(3); long start=System.currentTimeMillis();
        AnimatedSea(Activity a){super(a);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight(); float t=(System.currentTimeMillis()-start)/1000f;
            p.setShader(new LinearGradient(0,0,w,h,new int[]{0xFF180B43,0xFF182A83,0xFF071A4B},null,Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
            // Moon glow and moon
            float mx=w*.72f+(float)Math.sin(t*.12f)*w*.012f, my=h*.29f;
            p.setShader(new RadialGradient(mx,my,h*.22f,new int[]{0x99E9B8FF,0x337C5CFF,0x007C5CFF},null,Shader.TileMode.CLAMP)); c.drawCircle(mx,my,h*.22f,p); p.setShader(null);
            p.setColor(0xFFFFD9FF); c.drawCircle(mx,my,h*.085f,p);
            p.setColor(0x44FFFFFF); for(int i=0;i<55;i++){float x=(i*137f)%w;float y=(i*71f)%(h*.53f);float r=1.2f+(i%3);p.setAlpha((int)(70+60*(.5+.5*Math.sin(t+i))));c.drawCircle(x,y,r,p);} p.setAlpha(255);
            // distant island silhouettes
            p.setColor(0x553A2D91); c.drawOval(-w*.1f,h*.48f,w*.42f,h*.61f,p); c.drawOval(w*.60f,h*.49f,w*1.1f,h*.62f,p);
            // water reflection
            p.setShader(new android.graphics.LinearGradient(0,h*.54f,0,h,new int[]{0x447B73FF,0x223C4DCC,0x003C4DCC},null,Shader.TileMode.CLAMP)); c.drawRect(0,h*.54f,w,h,p); p.setShader(null);
            p.setColor(0x33E9B8FF); for(int i=0;i<18;i++){float yy=h*.59f+i*h*.018f; float ww=(float)(w*.04f+Math.abs(Math.sin(t*.5+i))*w*.14f); c.drawRoundRect(mx-ww,yy,mx+ww,yy+2,2,2,p);}
            postInvalidateDelayed(50);
        }
    }
}
