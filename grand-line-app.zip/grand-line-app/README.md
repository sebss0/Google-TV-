# Grand Line (launcher Android TV)

Proyecto Kotlin sin dependencias externas (solo SDK de Android).

## Compilar
1. Abre esta carpeta en Android Studio (genera el wrapper de Gradle) o ejecuta `gradle assembleDebug`.
2. APK: `app/build/outputs/apk/debug/app-debug.apk`
3. Instalar: `adb connect IP_DEL_TV` y `adb install -r app-debug.apk`
4. Pulsa HOME en el control y elige "Grand Line" como inicio.

## Recursos opcionales (si faltan, se usan alternativas)
- `app/src/main/assets/onepiece-logo.png` y `thousand-sunny.png`
- `app/src/main/assets/fonts/`: `PirataOne-Regular.ttf`, `Rye-Regular.ttf`, `Nunito-Italic.ttf` (Google Fonts, OFL)

## Incluido / pendiente
Incluido: paisaje por hora, nubes, mar, palmera, Sunny, carrusel WANTED con D-pad, Log Pose, Wi-Fi, botones.
Pendiente: Bitácora (ajustes), panel de entradas HDMI propio, cuadrícula de mini carteles, ordenar apps.
