package com.grandline.tv

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.Drawable
import android.provider.Settings
import android.view.KeyEvent
import android.view.SoundEffectConstants
import android.view.View
import java.util.Calendar
import java.util.Random
import kotlin.math.*

class AppItem(val label: String, val pkg: String, val icon: Drawable) { var poster: Bitmap? = null }

class LauncherView(ctx: Context) : View(ctx) {
    var running = false
    private val W = 1920f; private val H = 1080f; private val HOR = 640f
    private var apps = listOf<AppItem>(); private var showAll = false
    private var pos = 0f; private var target = 0
    private var row = 0; private var btn = 0; private var top = 0
    private var spin = 0f; private var mode = -1
    private var bg: Bitmap? = null; private var clouds: Bitmap? = null
    private var logo: Bitmap? = null; private var sunny: Bitmap? = null
    private val t0 = System.nanoTime(); private val rnd = Random(7)
    private val phase = FloatArray(8) { rnd.nextFloat() * 6.28f }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pirata = font("PirataOne-Regular.ttf", Typeface.create(Typeface.SERIF, Typeface.BOLD))
    private val rye = font("Rye-Regular.ttf", Typeface.create(Typeface.SERIF, Typeface.BOLD))
    private val nunito = font("Nunito-Italic.ttf", Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC))
    private val GOLD = 0xFFE9B949.toInt(); private val PARCH = 0xFFF2E3C6.toInt(); private val OCEAN = 0xFF0B2545.toInt()
    private val BROWN = 0xFF4A2E14.toInt()
    private val xs = floatArrayOf(0f, 330f, 585f, 790f); private val sc = floatArrayOf(1f, .82f, .66f, .52f)
    private val dk = floatArrayOf(0f, .38f, .62f, .8f)
    private val prio = listOf("netflix", "youtube", "disney", "amazon", "crunchyroll", "youtube.music", "vending", "settings")
    private val rewards = listOf("netflix" to "3.000.000.000", "youtube.music" to "330.000.000", "youtube" to "1.111.000.000",
        "disney" to "1.032.000.000", "amazon" to "930.000.000", "crunchyroll" to "500.000.000", "vending" to "66.000.000", "settings" to "1")
    private val quips = mapOf("netflix" to "Se busca vivo o en el sofá", "youtube.music" to "Canta a todo pulmón en cubierta",
        "youtube" to "Visto por última vez en «un video más»", "disney" to "Navega entre princesas y piratas",
        "amazon" to "Entregas desde el Nuevo Mundo", "crunchyroll" to "Reincidente: maratones de anime",
        "vending" to "Mercader de la Gran Ruta", "settings" to "Solo un grumete")

    init { isFocusable = true; isFocusableInTouchMode = true
        logo = asset("onepiece-logo.png"); sunny = asset("thousand-sunny.png")?.let { flipH(it) } }

    private fun font(n: String, fb: Typeface) = try { Typeface.createFromAsset(context.assets, "fonts/$n") } catch (e: Exception) { fb }
    private fun asset(n: String) = try { context.assets.open(n).use { android.graphics.BitmapFactory.decodeStream(it) } } catch (e: Exception) { null }
    private fun flipH(b: Bitmap) = Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { preScale(-1f, 1f) }, true)

    fun goHome() { row = 0; invalidate() }

    fun reload() {
        val pm = context.packageManager
        val found = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (r in pm.queryIntentActivities(i, 0)) {
                val pk = r.activityInfo.packageName
                if (pk == context.packageName || found.containsKey(pk)) continue
                found[pk] = AppItem(r.loadLabel(pm).toString(), pk, r.loadIcon(pm))
            }
        }
        val all = found.values.toList()
        val ordered = prio.mapNotNull { k -> all.firstOrNull { it.pkg.contains(k) } }.distinct()
        apps = if (showAll) all.sortedBy { it.label } else (ordered + all.filter { it !in ordered }).take(8)
        target = target.coerceIn(0, max(0, apps.size - 1))
    }

    private fun slot() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY).let { if (it in 5..11) 0 else if (it in 12..18) 1 else 2 }

    // ---------- teclas ----------
    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        when (k) {
            KeyEvent.KEYCODE_DPAD_LEFT -> move(-1)
            KeyEvent.KEYCODE_DPAD_RIGHT -> move(1)
            KeyEvent.KEYCODE_DPAD_DOWN -> row = if (row == 2) 0 else min(1, row + 1)
            KeyEvent.KEYCODE_DPAD_UP -> row = if (row == 0) 2 else 0
            KeyEvent.KEYCODE_BACK -> row = 0
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> activate()
            else -> return super.onKeyDown(k, e)
        }
        playSoundEffect(if (k == KeyEvent.KEYCODE_DPAD_CENTER) SoundEffectConstants.CLICK else SoundEffectConstants.NAVIGATION_RIGHT)
        invalidate(); return true
    }
    private fun move(d: Int) = when (row) {
        0 -> { target = (target + d).coerceIn(0, max(0, apps.size - 1)); spin += 40f * d }
        1 -> btn = (btn + d).coerceIn(0, 2)
        else -> top = (top + d).coerceIn(0, 1)
    }
    private fun go(i: Intent) { try { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {} }
    private fun activate() {
        when (row) {
            0 -> apps.getOrNull(target)?.let { a -> context.packageManager.getLaunchIntentForPackage(a.pkg)?.let { go(it) } }
            1 -> when (btn) {
                0 -> { val i = Intent(Intent.ACTION_VIEW).setClassName("com.android.tv.settings", "com.android.tv.settings.MainSettings")
                    go(if (i.resolveActivity(context.packageManager) != null) i else Intent(Settings.ACTION_SETTINGS)) }
                1 -> go(Intent(Settings.ACTION_SETTINGS))
                else -> { showAll = !showAll; target = 0; pos = 0f; reload() }
            }
            else -> if (top == 0) spin += 360f else go(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
    }

    // ---------- dibujo ----------
    override fun onDraw(c: Canvas) {
        if (!running && bg != null) { /* un cuadro final */ }
        val t = (System.nanoTime() - t0) / 1e9f
        if (slot() != mode) buildBackground(slot())
        val s = min(width / W, height / H)
        c.save(); c.translate((width - W * s) / 2, (height - H * s) / 2); c.scale(s, s)
        c.drawBitmap(bg!!, 0f, 0f, p)
        drawClouds(c, t); drawSea(c, t); drawHeader(c); drawCarousel(c, t); drawButtons(c); drawTop(c, t)
        logo?.let { val w = 360f; val h = w * it.height / it.width; c.drawBitmap(it, null, RectF(W * .95f - w, H * .95f - h, W * .95f, H * .95f), p) }
        c.restore()
        pos += (target - pos) * 0.16f; if (abs(target - pos) < .002f) pos = target.toFloat()
        spin *= 0.93f
        if (running) postInvalidateOnAnimation()
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, tf: Typeface, al: Paint.Align = Paint.Align.LEFT, shadow: Boolean = true) {
        p.typeface = tf; p.textSize = size; p.textAlign = al; p.style = Paint.Style.FILL
        if (shadow) p.setShadowLayer(4f, 0f, 2f, 0xAA000000.toInt())
        p.color = col; c.drawText(s, x, y, p); p.clearShadowLayer()
    }

    private fun drawHeader(c: Canvas) {
        val cal = Calendar.getInstance(); val h = cal.get(Calendar.HOUR_OF_DAY)
        val g = when (slot()) { 0 -> "¡Buenos días, nakama!"; 1 -> "¡Buenas tardes, nakama!"; else -> "Noche de travesía, nakama" }
        val x = W * .05f; val y = H * .05f
        txt(c, g, x, y + 60, 56f, GOLD, pirata)
        val tm = "%02d:%02d".format(h, cal.get(Calendar.MINUTE))
        txt(c, tm, x, y + 210, 140f, 0xFFF7F9FB.toInt(), pirata)
        p.typeface = pirata; p.textSize = 140f; val tw = p.measureText(tm)
        p.color = GOLD; c.drawRect(x + tw + 28, y + 100, x + tw + 31, y + 215, p)
        val dias = arrayOf("Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado")
        val mes = arrayOf("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")
        txt(c, dias[cal.get(Calendar.DAY_OF_WEEK) - 1], x + tw + 50, y + 150, 44f, GOLD, pirata)
        txt(c, "${cal.get(Calendar.DAY_OF_MONTH)} de ${mes[cal.get(Calendar.MONTH)]}", x + tw + 50, y + 205, 44f, GOLD, pirata)
    }

    private fun lerp(a: FloatArray, d: Float): Float { val i = min(d.toInt(), a.size - 2); return a[i] + (a[i + 1] - a[i]) * (d - i) }

    private fun drawCarousel(c: Canvas, t: Float) {
        if (apps.isEmpty()) return
        val cx = W / 2; val cy = 470f
        val order = apps.indices.sortedByDescending { abs(it - pos) }
        for (i in order) {
            val d = i - pos; val ad = abs(d); if (ad > 3f) continue
            val a = apps[i]; val bmp = a.poster ?: drawPoster(a).also { a.poster = it }
            val scl = lerp(sc, ad); val x = cx + sign(d) * lerp(xs, ad); val dim = lerp(dk, ad)
            val lift = if (ad < 1f) -(1 - ad) * 20f else 0f
            c.save(); c.translate(x, cy + lift); c.scale(scl, scl)
            val w = 600f * .62f; val hh = 840f * .62f
            val dst = RectF(-w / 2, -hh / 2, w / 2, hh / 2)
            if (ad < 1f) { p.color = GOLD; p.alpha = ((1 - ad) * 70).toInt(); p.maskFilter = BlurMaskFilter(40f, BlurMaskFilter.Blur.NORMAL)
                c.drawRoundRect(dst, 20f, 20f, p); p.maskFilter = null; p.alpha = 255 }
            val ycam = Camera(); val m = Matrix(); ycam.save(); ycam.rotateY(-d.coerceIn(-1f, 1f) * 22f); ycam.getMatrix(m); ycam.restore()
            c.concat(m)
            p.alpha = 255; c.drawBitmap(bmp, null, dst, p)
            if (dim > 0) { p.color = Color.BLACK; p.alpha = (dim * 255).toInt(); c.drawRect(dst, p); p.alpha = 255 }
            c.restore()
        }
        val f = apps[target]; val fade = if (abs(target - pos) < .5f) 255 else 0
        if (fade > 0) {
            txt(c, f.label, cx, 130f + 0f, 64f, GOLD, pirata, Paint.Align.CENTER)
            val q = quips.entries.firstOrNull { f.pkg.contains(it.key) }?.value ?: "Se busca vivo o en el sofá"
            txt(c, q, cx, 175f, 30f, 0xFFF7F9FB.toInt(), nunito, Paint.Align.CENTER)
        }
    }

    private fun drawButtons(c: Canvas) {
        val labels = arrayOf("ENTRADAS", "AJUSTES", if (showAll) "MIS APPS" else "TODAS LAS APPS")
        val ws = floatArrayOf(300f, 280f, 400f); var x = W / 2 - (ws.sum() + 60) / 2; val y = 880f
        for (i in 0..2) {
            val r = RectF(x, y, x + ws[i], y + 84f)
            p.color = PARCH; c.drawRoundRect(r, 42f, 42f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = BROWN; c.drawRoundRect(r, 42f, 42f, p); p.style = Paint.Style.FILL
            txt(c, labels[i], r.centerX(), r.centerY() + 12, 34f, BROWN, rye, Paint.Align.CENTER, false)
            if (row == 1 && btn == i) ring(c, r.left - 8, r.top - 8, r.right + 8, r.bottom + 8, 50f)
            x += ws[i] + 30
        }
    }

    private fun ring(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        p.style = Paint.Style.STROKE; p.color = GOLD; p.strokeWidth = 6f
        p.maskFilter = BlurMaskFilter(10f, BlurMaskFilter.Blur.SOLID); c.drawRoundRect(RectF(l, t, r, b), rad, rad, p)
        p.maskFilter = null; p.style = Paint.Style.FILL
    }

    private fun drawTop(c: Canvas, t: Float) {
        // Log Pose
        val lx = W * .95f - 230; val ly = 130f
        p.color = 0xFF8A5A2B.toInt(); c.drawOval(RectF(lx - 62, ly + 48, lx + 62, ly + 82), p)       // pedestal
        p.color = 0xFFB5793A.toInt(); c.drawRect(lx - 40, ly + 30, lx + 40, ly + 66, p)
        p.color = 0xFF5A3A1E.toInt(); c.drawRect(lx - 66, ly - 6, lx + 66, ly + 6, p)                   // brazalete
        p.color = 0xCCBFE8F5.toInt(); c.drawCircle(lx, ly, 52f, p)                                      // vidrio
        p.color = 0xFFF2E3C6.toInt(); c.drawCircle(lx, ly, 42f, p)
        val ang = sin(t * 1.3f + phase[0]) * 6f + (if (abs(target - pos) > .01f) sin(t * 12f) * 15f else 0f) + spin
        c.save(); c.rotate(ang, lx, ly)
        p.color = 0xFFC1121F.toInt(); c.drawPath(Path().apply { moveTo(lx, ly - 36); lineTo(lx + 7, ly); lineTo(lx - 7, ly); close() }, p)
        p.color = BROWN; c.drawPath(Path().apply { moveTo(lx, ly + 36); lineTo(lx + 7, ly); lineTo(lx - 7, ly); close() }, p)
        c.restore()
        if (row == 2 && top == 0) ring(c, lx - 72, ly - 62, lx + 72, ly + 86, 40f)
        // Wi-Fi (ojo de buey)
        val wx = lx + 150
        p.color = 0xFFB5793A.toInt(); c.drawCircle(wx, ly, 52f, p)
        p.color = 0xFF08213D.toInt(); c.drawCircle(wx, ly, 40f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = PARCH
        for (r in intArrayOf(12, 22, 32)) c.drawArc(RectF(wx - r, ly + 14 - r, wx + r, ly + 14 + r), 225f, 90f, false, p)
        p.style = Paint.Style.FILL; c.drawCircle(wx, ly + 14, 4f, p)
        if (row == 2 && top == 1) ring(c, wx - 62, ly - 62, wx + 62, ly + 62, 62f)
    }

    private fun drawClouds(c: Canvas, t: Float) {
        val cb = clouds ?: return; val off = (t * 0.83f) % W    // ~50 px/min
        c.drawBitmap(cb, -off, 60f, p); c.drawBitmap(cb, W - off, 60f, p)
    }

    private fun drawSea(c: Canvas, t: Float) {
        val m = mode
        // camino de luz
        val lc = if (m == 2) 0xFFCFE0FF.toInt() else if (m == 1) 0xFFFFD27A.toInt() else 0xFFFFFFFF.toInt()
        val lx = if (m == 2) W * .78f else W * .75f
        for (k in 0..1) { p.color = lc; p.alpha = (50 + 30 * sin(t * 2f + k * 2f)).toInt()
            for (j in 0 until 14) { val y = HOR + 12 + j * 22f; val w = 20f + j * 10f + 6 * sin(t * 1.6f + j + k)
                c.drawRect(lx - w / 2 + k * 10, y, lx + w / 2 + k * 10, y + 4f, p) } }
        p.alpha = 255
        // crestas
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = 0x55FFFFFF
        for (i in 0 until 7) { val y = HOR + 30 + i * 52f; val path = Path(); path.moveTo(-20f, y)
            var x = -20f; while (x < W + 40) { path.lineTo(x, y + sin(x / 90f + t * (.6f + i * .1f) + i) * (3f + i * 1.5f)); x += 40f }
            c.drawPath(path, p) }
        p.style = Paint.Style.FILL
        // palmera
        val bx = W * .88f; val by = HOR - 40
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = 0xFF0A1A12.toInt()
        c.drawLine(bx, by + 30, bx + 6 * sin(t * .9f + phase[1]), by - 60, p)
        for (i in 0 until 5) { val a = (-150 + i * 30 + 6 * sin(t * 1.4f + i + phase[2])) * Math.PI / 180
            c.drawLine(bx + 6 * sin(t * .9f + phase[1]), by - 60, bx + 6 * sin(t * .9f + phase[1]) + (cos(a) * 46).toFloat(), by - 60 + (sin(a) * 30).toFloat() + 12, p) }
        p.style = Paint.Style.FILL
        // Thousand Sunny
        sunny?.let { b ->
            val w = 190f; val h = w * b.height / b.width
            val x = 280f + 40 * sin(t * .05f + phase[3]); val y = HOR - h + 22 + 2.5f * sin(t * 1.1f + phase[4])
            c.save(); c.rotate(1.5f * sin(t * .8f + phase[5]), x + w / 2, y + h)
            p.alpha = 205; c.drawBitmap(b, null, RectF(x, y, x + w, y + h - 14), p); p.alpha = 255
            p.color = 0xAAFFFFFF.toInt(); c.drawOval(RectF(x + 10, HOR + 4, x + w - 10, HOR + 14), p)  // espuma
            c.restore()
        }
        // degradado inferior para el texto
        p.shader = LinearGradient(0f, 760f, 0f, H, 0x00000000, 0xAA000000.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 760f, W, H, p); p.shader = null
    }

    // ---------- capas pre-pintadas ----------
    private fun buildBackground(m: Int) {
        mode = m
        val sky = arrayOf(intArrayOf(0xFF1F5FA8.toInt(), 0xFF5EA7E0.toInt(), 0xFFA9D6F2.toInt(), 0xFFE9F5FB.toInt()),
            intArrayOf(0xFF0B2545.toInt(), 0xFF3A3D76.toInt(), 0xFF9C4F78.toInt(), 0xFFF08A4B.toInt(), 0xFFFFCF73.toInt()),
            intArrayOf(0xFF02060F.toInt(), 0xFF071A36.toInt(), 0xFF163463.toInt(), 0xFF25497D.toInt()))[m]
        val sea = arrayOf(intArrayOf(0xFF9FD4EA.toInt(), 0xFF4EA3CF.toInt(), 0xFF1F6AA6.toInt(), 0xFF0B3A6A.toInt()),
            intArrayOf(0xFFD8875A.toInt(), 0xFF7B4F74.toInt(), 0xFF283C6E.toInt(), 0xFF071A33.toInt()),
            intArrayOf(0xFF2C4F80.toInt(), 0xFF173562.toInt(), 0xFF0A1F3F.toInt(), 0xFF030B18.toInt()))[m]
        val b = Bitmap.createBitmap(1920, 1080, Bitmap.Config.RGB_565); val c = Canvas(b); val q = Paint(Paint.ANTI_ALIAS_FLAG)
        q.shader = LinearGradient(0f, 0f, 0f, HOR, sky, null, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, HOR, q)
        q.shader = LinearGradient(0f, HOR, 0f, H, sea, null, Shader.TileMode.CLAMP); c.drawRect(0f, HOR, W, H, q)
        if (m == 2) { val r = Random(3); q.shader = null; q.color = Color.WHITE
            for (i in 0 until 90) { q.alpha = 80 + r.nextInt(170); c.drawCircle(r.nextFloat() * W, r.nextFloat() * (HOR - 60), 1f + r.nextFloat() * 1.6f, q) } }
        val sx = if (m == 1) W * .75f else if (m == 0) W * .8f else W * .78f
        val sy = if (m == 1) HOR - 70f else if (m == 0) 170f else 190f
        val sr = if (m == 1) 95f else if (m == 0) 60f else 52f
        val halo = if (m == 2) 0xFFBFD6FF.toInt() else if (m == 1) 0xFFFFC85A.toInt() else 0xFFFFF3C4.toInt()
        q.shader = RadialGradient(sx, sy, sr * 4.5f, (halo and 0xFFFFFF) or 0x99000000.toInt(), halo and 0xFFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(sx, sy, sr * 4.5f, q); q.shader = null; q.color = if (m == 2) 0xFFEAF2FF.toInt() else if (m == 1) 0xFFFFE08A.toInt() else Color.WHITE
        c.drawCircle(sx, sy, sr, q)
        q.color = if (m == 2) 0xFF040C18.toInt() else 0xFF14313F.toInt()   // isla
        c.drawOval(RectF(W * .78f, HOR - 60, W * .98f, HOR + 6), q)
        q.color = 0x33FFFFFF; c.drawRect(0f, HOR - 2, W, HOR + 2, q)
        q.shader = LinearGradient(0f, 0f, 0f, 300f, 0x88000000.toInt(), 0x00000000, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, 300f, q)
        bg = b
        // nubes: decenas de "puffs" con degradado radial, pintadas una sola vez
        val cb = Bitmap.createBitmap(1920, 380, Bitmap.Config.ARGB_8888); val cc = Canvas(cb); val r = Random(11)
        val lit = if (m == 1) 0xFFFFD9A8.toInt() else if (m == 2) 0xFF6F86B0.toInt() else Color.WHITE
        val shade = if (m == 1) 0xFF8A5A78.toInt() else if (m == 2) 0xFF1B2F57.toInt() else 0xFFBCD3E6.toInt()
        for (n in 0 until 7) { val ox = n * 280f + r.nextFloat() * 100; val oy = 60 + r.nextFloat() * 200; val sz = .6f + r.nextFloat() * .8f
            for (k in 0 until 26) { val px = ox + (r.nextFloat() - .5f) * 200 * sz; val py = oy - abs(r.nextFloat() - .3f) * 50 * sz; val rad = (22 + r.nextFloat() * 30) * sz
                val col = if (px > ox) lit else shade
                q.shader = RadialGradient(px, py, rad, (col and 0xFFFFFF) or 0xC8000000.toInt(), col and 0xFFFFFF, Shader.TileMode.CLAMP); cc.drawCircle(px, py, rad, q) } }
        clouds = cb
    }

    // ---------- cartel WANTED ----------
    private fun fit(s: String, w: Float, max: Float, tf: Typeface): Float { p.typeface = tf; p.textSize = 100f; return min(max, 100f * w / p.measureText(s)) }

    private fun drawPoster(a: AppItem): Bitmap {
        val b = Bitmap.createBitmap(600, 840, Bitmap.Config.ARGB_8888); val c = Canvas(b); val r = Random(a.pkg.hashCode().toLong())
        val path = Path(); val n = 60
        fun pt(i: Int): PointF { val f = i / n.toFloat() * 4; val e = (f.toInt() % 4); val u = f - f.toInt(); val j = r.nextFloat() * 8
            return when (e) { 0 -> PointF(24 + u * 552, 24 + j); 1 -> PointF(576 - j, 24 + u * 792); 2 -> PointF(576 - u * 552, 816 - j); else -> PointF(24 + j, 816 - u * 792) } }
        for (i in 0 until n) { val q = pt(i); if (i == 0) path.moveTo(q.x, q.y) else path.lineTo(q.x, q.y) }; path.close()
        p.color = 0x99000000.toInt(); p.maskFilter = BlurMaskFilter(14f, BlurMaskFilter.Blur.NORMAL); c.save(); c.translate(6f, 10f); c.drawPath(path, p); c.restore(); p.maskFilter = null
        p.shader = LinearGradient(0f, 0f, 0f, 840f, intArrayOf(0xFFF6E8CC.toInt(), 0xFFEBD5A6.toInt(), 0xFFE0C28A.toInt()), null, Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 26f; p.color = 0x886B3F14.toInt(); p.maskFilter = BlurMaskFilter(14f, BlurMaskFilter.Blur.NORMAL)
        c.save(); c.clipPath(path); c.drawPath(path, p); c.restore(); p.maskFilter = null; p.style = Paint.Style.FILL
        txt(c, "WANTED", 300f, 118f, fit("WANTED", 470f, 120f, rye), BROWN, rye, Paint.Align.CENTER, false)
        val fr = RectF(70f, 140f, 530f, 360f); p.color = 0xFF1B2A41.toInt(); c.drawRect(fr, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.color = BROWN; c.drawRect(fr, p); p.style = Paint.Style.FILL
        a.icon.setBounds(300 - 90, 250 - 90, 300 + 90, 250 + 90); a.icon.draw(c)
        txt(c, "VIVO O EN EL SOFÁ", 300f, 425f, fit("VIVO O EN EL SOFÁ", 400f, 44f, rye), BROWN, rye, Paint.Align.CENTER, false)
        txt(c, a.label.take(18), 300f, 520f, fit(a.label.take(18), 430f, 100f, pirata), BROWN, pirata, Paint.Align.CENTER, false)
        val amt = rewards.firstOrNull { a.pkg.contains(it.first) }?.second ?: "1.000.000"
        val rw = "฿ $amt-"; txt(c, rw, 300f, 610f, fit(rw, 400f, 62f, rye), BROWN, rye, Paint.Align.CENTER, false)
        for ((i, l) in listOf("ESTE CARTEL ES PURA FICCIÓN.", "CUALQUIER PARECIDO CON TU MARATÓN", "DEL DOMINGO ES PURA COINCIDENCIA.").withIndex())
            txt(c, l, 60f, 760f + i * 16f, 11f, BROWN, nunito, Paint.Align.LEFT, false)
        txt(c, "MARINE", 540f, 790f, 28f, BROWN, rye, Paint.Align.RIGHT, false)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND; p.color = BROWN   // S de pluma
        for (sx in floatArrayOf(44f, 556f)) { val s = Path(); s.moveTo(sx, 450f); s.cubicTo(sx + 16, 465f, sx - 16, 490f, sx, 505f); s.cubicTo(sx + 16, 520f, sx - 16, 545f, sx, 560f); c.drawPath(s, p) }
        p.style = Paint.Style.FILL; return b
    }
}
