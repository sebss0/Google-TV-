package com.grandline.tv

import android.app.Activity
import android.os.Bundle

class MainActivity : Activity() {
    private lateinit var view: LauncherView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        view = LauncherView(this)
        setContentView(view)
        view.requestFocus()
    }
    override fun onResume() { super.onResume(); view.reload(); view.running = true; view.invalidate() }
    override fun onPause() { view.running = false; super.onPause() }
    override fun onBackPressed() { /* el launcher no se cierra */ view.goHome() }
}
