# Liquid Home TV

Launcher Android TV minimalista con reloj grande, accesos a Ajustes y Aplicaciones, tarjetas de apps instaladas y un fondo animado de mar nocturno azul/morado.

## Compilar la APK

El proyecto necesita Android SDK Platform 35, Android Build Tools 35.0.0, Java 17 y Gradle 8.9.

### Compilación automática en GitHub (sin instalar Android Studio)

1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de esta carpeta al repositorio (la carpeta `.github` incluida).
3. Abre la pestaña **Actions**.
4. Selecciona **Build Liquid Home TV APK** y pulsa **Run workflow** (o espera a que termine el primer push).
5. Al terminar, abre la ejecución y descarga el artefacto **LiquidHomeTV-debug**. Dentro estará `app-debug.apk`.

### Compilación local

Desde esta carpeta, ejecuta:

```bash
gradle --no-daemon :app:assembleDebug
```

La APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en Google TV

1. Copia `app-debug.apk` a una memoria USB o usa una aplicación de transferencia de archivos.
2. En Google TV, permite instalar aplicaciones de esa fuente cuando Android lo solicite.
3. Instala la APK y pulsa el botón Inicio del mando.
4. Selecciona **Liquid Home TV** como aplicación de inicio. Si no aparece el selector, ve a Ajustes > Aplicaciones > Aplicaciones predeterminadas > Aplicación de inicio (la ruta puede variar según el fabricante).

## Notas

- Es una primera versión funcional de launcher; el fondo es una animación generada por código, no un vídeo ni un wallpaper externo.
- Las aplicaciones visibles dependen de las apps que Android permita descubrir como lanzables en el dispositivo.
- La APK `debug` no está firmada para distribución en tiendas; sirve para pruebas e instalación personal.
