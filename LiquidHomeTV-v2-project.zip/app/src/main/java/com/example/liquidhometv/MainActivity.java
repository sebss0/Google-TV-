package com.example.liquidhometv;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private TextView clock, date, hint;
    private LinearLayout appStrip;
    private HorizontalScrollView scroller;
    private boolean editMode = false;
    private final ArrayList<String> orderedPackages = new ArrayList<>();
    private final HashMap<String, android.content.pm.ResolveInfo> appInfo = new HashMap<>();
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512 | 4096);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        FrameLayout root = new FrameLayout(this);
        root.addView(new AnimatedSea(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(48), dp(24), dp(48), dp(24));
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(top, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        LinearLayout timeBox = new LinearLayout(this);
        timeBox.setOrientation(LinearLayout.VERTICAL);
        top.addView(timeBox, new LinearLayout.LayoutParams(0, -2, 1f));
        date = text("", 19, 0xFFFFD889, true);
        clock = text("", 68, Color.WHITE, true);
        clock.setShadowLayer(12, 0, 4, 0xAA315DFF);
        timeBox.addView(date);
        timeBox.addView(clock);

        TextView status = text("◉   ◉   Wi-Fi", 18, 0xFFFFE6A6, true);
        status.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(status, new LinearLayout.LayoutParams(-2, -2));

        hint = text("TUS APLICACIONES", 14, 0xFFFFE9BD, true);
        hint.setLetterSpacing(.12f);
        hint.setPadding(0, 0, 0, dp(12));
        page.addView(hint);

        scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setClipToPadding(false);
        scroller.setFillViewport(false);
        page.addView(scroller, new LinearLayout.LayoutParams(-1, dp(245)));
        appStrip = new LinearLayout(this);
        appStrip.setOrientation(LinearLayout.HORIZONTAL);
        appStrip.setGravity(Gravity.CENTER_VERTICAL);
        scroller.addView(appStrip, new HorizontalScrollView.LayoutParams(-2, -1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(0, dp(14), 0, 0);
        page.addView(bottom, new LinearLayout.LayoutParams(-1, -2));
        TextView inputs = pill("▱  ENTRADAS");
        TextView settings = pill("⚙  AJUSTES");
        TextView all = pill("▦  TODAS LAS APPS");
        bottom.addView(inputs); bottom.addView(space(14));
        bottom.addView(settings); bottom.addView(space(14)); bottom.addView(all);
        inputs.setOnClickListener(v -> Toast.makeText(this, "Entradas no disponibles en este dispositivo", Toast.LENGTH_SHORT).show());
        settings.setOnClickListener(v -> { try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); } catch(Exception ignored){} });
        all.setOnClickListener(v -> { if(appStrip.getChildCount()>0) appStrip.getChildAt(0).requestFocus(); });

        setContentView(root);
        populateApps();
        updateTime();
        handler.postDelayed(new Runnable(){ public void run(){ updateTime(); handler.postDelayed(this, 1000); }}, 1000);
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void updateTime() {
        Date now = new Date();
        clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
        String d = new SimpleDateFormat("EEEE, d 'de' MMMM", new Locale("es","ES")).format(now);
        if (d.length()>0) d = d.substring(0,1).toUpperCase(new Locale("es","ES")) + d.substring(1);
        date.setText(d);
    }

    private void populateApps() {
        appStrip.removeAllViews(); appInfo.clear();
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> found = pm.queryIntentActivities(query, 0);
        final ArrayList<String> discovered = new ArrayList<>();
        for (android.content.pm.ResolveInfo ri : found) {
            String pkg = ri.activityInfo.packageName;
            if (!pkg.equals(getPackageName()) && !appInfo.containsKey(pkg)) { appInfo.put(pkg, ri); discovered.add(pkg); }
        }
        Collections.sort(discovered, (a,b) -> String.valueOf(appInfo.get(a).loadLabel(pm)).compareToIgnoreCase(String.valueOf(appInfo.get(b).loadLabel(pm))));
        ArrayList<String> saved = new ArrayList<>();
        String raw = prefs.getString("order", "");
        if (!raw.isEmpty()) saved.addAll(Arrays.asList(raw.split("\\n")));
        orderedPackages.clear();
        for (String pkg : saved) if (appInfo.containsKey(pkg) && !orderedPackages.contains(pkg)) orderedPackages.add(pkg);
        for (String pkg : discovered) if (!orderedPackages.contains(pkg)) orderedPackages.add(pkg);
        for (String pkg : orderedPackages) addAppCard(pkg);
        if (appStrip.getChildCount() > 0) appStrip.getChildAt(0).requestFocus();
    }

    private void addAppCard(String pkg) {
        android.content.pm.ResolveInfo ri = appInfo.get(pkg);
        if (ri == null) return;
        LinearLayout poster = new LinearLayout(this);
        poster.setOrientation(LinearLayout.VERTICAL);
        poster.setGravity(Gravity.CENTER);
        poster.setPadding(dp(7), dp(7), dp(7), dp(8));
        poster.setFocusable(true); poster.setFocusableInTouchMode(true);
        poster.setBackground(posterBackground(false));
        TextView wanted = text("WANTED", 18, 0xFF34291D, true);
        wanted.setGravity(Gravity.CENTER);
        poster.addView(wanted, new LinearLayout.LayoutParams(-1, dp(31)));
        View line = new View(this); line.setBackgroundColor(0xFF9A7C54);
        poster.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        ImageView icon = new ImageView(this);
        try { icon.setImageDrawable(ri.loadIcon(getPackageManager())); } catch(Exception ignored) {}
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(58), dp(58));
        ip.topMargin = dp(9); ip.bottomMargin = dp(4); poster.addView(icon, ip);
        TextView label = text(String.valueOf(ri.loadLabel(getPackageManager())), 14, 0xFF30251D, true);
        label.setGravity(Gravity.CENTER); label.setMaxLines(2);
        poster.addView(label, new LinearLayout.LayoutParams(-1, dp(38)));
        TextView bounty = text("SE BUSCA EN EL SOFÁ", 8, 0xFF806744, true);
        bounty.setGravity(Gravity.CENTER);
        poster.addView(bounty, new LinearLayout.LayoutParams(-1, dp(18)));

        poster.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); }
        });
        poster.setOnLongClickListener(v -> {
            editMode = true;
            hint.setText("MODO ORDENAR · USA ◀ ▶ PARA MOVER · OK PARA TERMINAR");
            Toast.makeText(this, "Modo ordenar: usa izquierda/derecha y pulsa OK para terminar", Toast.LENGTH_LONG).show();
            return true;
        });
        poster.setOnFocusChangeListener((v, focused) -> {
            v.animate().scaleX(focused ? 1.12f : 1f).scaleY(focused ? 1.12f : 1f)
                .alpha(focused ? 1f : .94f).setDuration(150).start();
            v.setElevation(focused ? dp(18) : dp(2));
            v.setBackground(posterBackground(focused));
            if (focused) {
                int left = v.getLeft(), right = v.getRight();
                scroller.smoothScrollTo(Math.max(0, left - dp(100)), 0);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(142), dp(218));
        lp.setMargins(dp(4), dp(8), dp(17), dp(8));
        appStrip.addView(poster, lp);
    }

    private GradientDrawable posterBackground(boolean focused) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(focused ? 0xFFFFF1CF : 0xFFE9D8B4);
        d.setCornerRadius(dp(5));
        d.setStroke(dp(focused ? 4 : 2), focused ? 0xFF55DFFF : 0xFF8D7048);
        return d;
    }

    private void moveFocused(int delta) {
        View focused = getCurrentFocus();
        int from = appStrip.indexOfChild(focused);
        int to = from + delta;
        if (from < 0 || to < 0 || to >= appStrip.getChildCount()) return;
        Collections.swap(orderedPackages, from, to);
        View a = appStrip.getChildAt(from), b = appStrip.getChildAt(to);
        appStrip.removeViewAt(Math.max(from,to));
        appStrip.removeViewAt(Math.min(from,to));
        appStrip.addView(b, from < to ? from : to);
        appStrip.addView(a, from < to ? to : from);
        focused.requestFocus();
        prefs.edit().putString("order", join(orderedPackages)).apply();
    }
    private String join(List<String> list) { StringBuilder b=new StringBuilder(); for(String s:list){if(b.length()>0)b.append("\n");b.append(s);} return b.toString(); }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (editMode) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { moveFocused(-1); return true; }
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) { moveFocused(1); return true; }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_BACK) {
                editMode = false; hint.setText("TUS APLICACIONES"); Toast.makeText(this, "Orden guardado", Toast.LENGTH_SHORT).show(); return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    private TextView pill(String s) {
        TextView t = text(s, 14, 0xFF33291D, true); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(19),dp(10),dp(19),dp(10)); t.setFocusable(true); t.setClickable(true);
        GradientDrawable d=new GradientDrawable(); d.setColor(0xFFF5E8C9); d.setCornerRadius(dp(28)); d.setStroke(dp(1),0xFF9E8053); t.setBackground(d);
        t.setOnFocusChangeListener((v,f)->{v.animate().scaleX(f?1.08f:1f).scaleY(f?1.08f:1f).setDuration(130).start();});
        return t;
    }
    private View space(int w) { View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),1)); return v; }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    @Override protected void onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); }

    private static class AnimatedSea extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); long start=System.currentTimeMillis();
        AnimatedSea(Activity a){super(a); setLayerType(View.LAYER_TYPE_HARDWARE,null);}
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(),h=getHeight(),t=(System.currentTimeMillis()-start)/10000f;
            p.setShader(new LinearGradient(0,0,0,h,new int[]{0xFF071B50,0xFF07559A,0xFF061B49},null,Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
            float mx=w*.72f+(float)Math.sin(t)*w*.012f, my=h*.48f;
            p.setShader(new RadialGradient(mx,my,h*.40f,new int[]{0x5578CFFF,0x2274BFFF,0x0074BFFF},null,Shader.TileMode.CLAMP)); c.drawCircle(mx,my,h*.40f,p); p.setShader(null);
            p.setColor(0xFF0A285D); c.drawOval(-w*.08f,h*.49f,w*.30f,h*.62f,p); c.drawOval(w*.79f,h*.47f,w*1.12f,h*.65f,p);
            // soft layered clouds
            p.setColor(0xAA1765B0);
            for(int i=0;i<7;i++){float x=((i*.19f+(t*.012f))%1.25f)*w-w*.1f; float y=h*(.28f+(i%3)*.075f); c.drawOval(x,y,x+w*.22f,y+h*.045f,p);}
            p.setColor(0xFF092B65); c.drawRect(0,h*.70f,w,h,p);
            p.setShader(new LinearGradient(0,h*.68f,0,h,new int[]{0x553DA5E8,0x22316CC2,0x00316CC2},null,Shader.TileMode.CLAMP)); c.drawRect(0,h*.68f,w,h,p); p.setShader(null);
            p.setColor(0x55B5E8FF);
            for(int i=0;i<22;i++){float yy=h*.73f+i*h*.014f; float x=((i*83f+t*25)%w); float ww=w*(.025f+(i%4)*.012f); c.drawRoundRect(x,yy,x+ww,yy+dp(1.2f),dp(2),dp(2),p);}
            postInvalidateDelayed(100);
        }
        private float dp(float n){return n*getResources().getDisplayMetrics().density;}
    }
}
